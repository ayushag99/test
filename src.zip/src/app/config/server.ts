const ServerConfig = {
  userService: 'http://localhost:3000/user',
  terminalService: '',
  vehicleService: '',
 terminal:{
   getAllTErminals:()=>"http://localhost:3000/terminals",
   getById:(id:string)=>`http://localhost:3000/terminals/${id}`
 },
 vehicle:{
   getAllVehicles:()=>"http://localhost:3000/vehicles",
   getVehicleById:(id:string)=>`http://localhost:3000/vehicles/${id}`
 }
};
export default ServerConfig;
