import { TerminalInterface } from '../models/interface/TerminalInterface';

const USER_SERVICES = 'http://localhost:3000/user';
const WORKITEM_SERVICE = 'http://localhost:3000/workitems';
const ServerConfig = {
  userService: 'http://localhost:3000/user',
  terminal: {
    getAllTErminals: () => 'http://localhost:3000/terminals',
    createTerminal: () =>
      'http://localhost:3000/terminals',
    updateTerminal: () =>
      'http://localhost:3000/terminals',
    getById: (id: string) => `http://localhost:3000/terminals/${id}`,
  },
  vehicle: {
    getAllVehicles: () => 'http://localhost:3000/vehicles',
    createVehicle: () => 'http://localhost:3000/vehicles',
    getVehicleById: (id: string) => `http://localhost:3000/vehicles/${id}`,
  },
  workItems: {
    getAllWorkItems: (userId: any) => `${WORKITEM_SERVICE}`,
    getWorkItemByUserId: (user_Id: any) =>
      `${WORKITEM_SERVICE}/user/${user_Id}`,
    getWrokItemById: (id: any) => `${WORKITEM_SERVICE}/${id}`,
    deleteWorkitemById: (id: any) => `${WORKITEM_SERVICE}/${id}`,
    registerWorkItem: () => `${WORKITEM_SERVICE}`,
    updateWorkItem: () => `${WORKITEM_SERVICE}`,
  },
  users: {
    registerUser: () => `${USER_SERVICES}`,
    updateUser: () => `${USER_SERVICES}`,
    getUserById: (user_id: any) => `${USER_SERVICES}/${user_id}`,
    deleteUser: (user_id: any) => `${USER_SERVICES}/${user_id}`,
    loginUser: () => `${USER_SERVICES}/login`,
    loginAdmin: () => `${USER_SERVICES}/admin/login`,
  },
};
export default ServerConfig;
