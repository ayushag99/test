import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { VehicleInterface } from '../../../models/interface/VehicleInterface';

@Component({
  selector: 'app-vehicle-form',
  templateUrl: './vehicle-form.component.html',
  styleUrls: ['./vehicle-form.component.css'],
})
export class VehicleFormComponent implements OnInit, OnChanges {
  @Input() vehicle!: VehicleInterface | null;
  @Input() isCreating = true;
  vehicleForm!: FormGroup;
  constructor() {}

  ngOnInit(): void {
    // if (!this.vehicle) {
    //   this.isCreating = true;
    // }
    this.vehicleForm = new FormGroup({
      vehicleNumber: new FormControl(
        this.vehicle ? this.vehicle.vehicleNumber : '',
        [Validators.required]
      ),
      vehicleName: new FormControl(
        this.vehicle ? this.vehicle.vehicleName : '',
        [Validators.required]
      ),
      maxLiftingCapacity: new FormControl(
        this.vehicle ? this.vehicle.maxLiftingCapacity : '',
        [Validators.required]
      ),
      retireDate: new FormControl(this.vehicle ? this.vehicle.retireDate : '', [
        Validators.required,
      ]),
      vehicleStatus: new FormControl(
        this.vehicle ? this.vehicle.vehicleStatus : '',
        [Validators.required]
      ),
      country: new FormControl(this.vehicle ? this.vehicle.country : '', [
        Validators.required,
      ]),
      harborLocation: new FormControl(
        this.vehicle ? this.vehicle.harborLocation : '',
        [Validators.required]
      ),
    });
  }
  ngOnChanges() {
    this.ngOnInit();
  }
  onSubmit() {}
}
