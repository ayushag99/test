import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserInterface } from '../models/interface/UserInterface';
import ServerConfig from '../config/server';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  url: string;
  isLoggedIn = false;
  isAdmin = false;
  user: UserInterface | null = null;
  createUserEvent = new EventEmitter<UserInterface>();
  updateUserEvent = new EventEmitter<UserInterface>();
  loginEvent = new EventEmitter<{ isLoggedIn: boolean; isAdmin: boolean }>();
  logoutEvent = new EventEmitter<UserInterface>();

  constructor(private http: HttpClient) {
    this.url = ServerConfig.userService;
  }

  registerNewUser(user: UserInterface) {
    return this.http.post(this.url, user);
  }
  updateUser(user: UserInterface) {
    return this.http.patch(this.url, user);
  }
  getUser(userId: number) {
    return this.http.get(`${this.url}/${userId}`);
  }
  deleteUser(userId: number) {
    return this.http.delete(`${this.url}/${userId}`);
  }
  loginUser(data: { email_id: string; password: string }) {
    return this.http.post(`${this.url}/login`, data);
  }
  adminLoginUser(data: { email_id: string; password: string }) {
    return this.http.post(`${this.url}/login`, data);
  }

  //  User Login
  adminLoginHandler(user: UserInterface) {
    this.isLoggedIn = true;
    this.isAdmin = true;
    this.user = user;
    console.log(this.isLoggedIn);
    this.loginEvent.emit({
      isLoggedIn: this.isLoggedIn,
      isAdmin: this.isAdmin,
    });
  }
  loginHandler(user: UserInterface) {
    this.isLoggedIn = true;
    this.user = user;
    console.log(this.isLoggedIn);
    this.loginEvent.emit({
      isLoggedIn: this.isLoggedIn,
      isAdmin: this.isAdmin,
    });
  }
  logoutHandler() {
    this.isAdmin = false;
    this.isLoggedIn = false;
    this.loginEvent.emit({
      isLoggedIn: this.isLoggedIn,
      isAdmin: this.isAdmin,
    });
  }
  isAuthenticated() {
    const promise = new Promise((resolve, reject) => [
      setTimeout(() => {
        resolve(this.isLoggedIn);
      }, 800),
    ]);
    return promise;
  }
}
