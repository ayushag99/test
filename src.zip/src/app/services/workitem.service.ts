import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WorkitemService {

  constructor(private http: HttpClient) { 

  }

  getWorItemById(userId:number,workItemId:string){
    return this.http.get("http://localhost:3000/user/1234/workitems/1234")
  }
  getAllWorItems(userId:number){
    return this.http.get("http://localhost:3000/user/1234/workitems")
  }
  deleteWOrkItem(workItemId:string){
    return this.http.delete("http://localhost:3000/user/1234/workitems/1234")
  }
}
