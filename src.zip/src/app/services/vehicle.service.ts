import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import ServerConfig from '../config/server';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor(private http: HttpClient) { }

  getAllVehicle(){
    return this.http.get(ServerConfig.vehicle.getAllVehicles())
  }

  getVehicleById(id:string){
    return this.http.get(ServerConfig.vehicle.getVehicleById(id))
  }
}
