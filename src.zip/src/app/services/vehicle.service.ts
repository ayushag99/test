import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import ServerConfig from '../config/server';
import { VehicleInterface } from '../models/interface/VehicleInterface';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {

  constructor(private http: HttpClient) { }

  getAllVehicle(){
    return this.http.get(ServerConfig.vehicle.getAllVehicles())
  }

  getVehicleById(id:string){
    return this.http.get(ServerConfig.vehicle.getVehicleById(id))}
  updateVehicle(vehicle:VehicleInterface){
    return this.http.patch(ServerConfig.vehicle.createVehicle(),vehicle)}
  createVehicle(vehicle:VehicleInterface){
    return this.http.post(ServerConfig.vehicle.createVehicle(),vehicle)
  }

}
