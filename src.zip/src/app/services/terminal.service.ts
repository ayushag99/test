import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import ServerConfig from '../config/server';

@Injectable({
  providedIn: 'root',
})
export class TerminalService {
  constructor(private http: HttpClient) {}
  getAllTerminals() {
    return this.http.get(ServerConfig.terminal.getAllTErminals());
  }
  getById(id:string){
    return this.http.get(ServerConfig.terminal.getById(id))
  }
}
