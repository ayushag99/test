export interface TerminalInterface {
  terminalId?: string;

  terminalName?: string;

  country?: string;

  itemType?: string;

  terminalDescription?: string;

  capacity?: number;

  Availablecapacity?: number;

  status?: string;

  harborLocation?: string;
}
